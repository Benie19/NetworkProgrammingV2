import socket
import threading

# Connect to the bootstrap node
bootstrap_ip = "127.0.0.1"
bootstrap_port = 4000
client_ip = int(input("Enter last octet for client IP (e.g., 2 for 127.0.0.2): "))
client_ip = f"127.0.0.{client_ip}"

# Connect to bootstrap from the same IP but different port
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.bind((client_ip, 0))  # Bind to same IP, any available port
client_socket.connect((bootstrap_ip, bootstrap_port))

# Receive the list of known peers
peer_list = client_socket.recv(1024).decode()
print(f"Known Peers: {peer_list}")

client_socket.close()

# Now create listening socket on port 5000
listener_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
listener_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
listener_socket.bind((client_ip, 5000))
listener_socket.listen(5)

def send_message(p):
    peers = p
    while True:
        ip_send = '127.0.0.' + input("last octet of peer IP to send message to: ")
        if ip_send not in peers:
            bootstrap_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            bootstrap_socket.bind((client_ip, 0))  # Bind to same IP, any available port
            bootstrap_socket.connect((bootstrap_ip, bootstrap_port))

            # Receive the list of known peers
            peers = bootstrap_socket.recv(1024).decode()

            bootstrap_socket.close()
            if ip_send not in peers:
                print(f"Peer {ip_send} not in known peer list.")
                continue
        message = input("Message to send: ")
        peer_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        peer_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        peer_socket.bind((client_ip, 6000))  # Bind to same IP, any available port
        peer_socket.connect((ip_send, 5000))
        peer_socket.sendall(message.encode())
        peer_socket.close()

def peer_listener():
    print("Peer is listening for messages...")
    while True:
        conn, addr = listener_socket.accept()
        message = conn.recv(1024).decode()
        print(f"Message from {addr}: {message}")
        conn.close()

# Start listening in a separate thread
threading.Thread(target=peer_listener, daemon=True).start()
threading.Thread(target=send_message, args=(peer_list,), daemon=True).start()

# Keep main thread alive
try:
    while True:
        pass
except KeyboardInterrupt:
    print("Shutting down...")
    listener_socket.close()